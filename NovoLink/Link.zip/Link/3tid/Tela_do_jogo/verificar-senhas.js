function cadastrar(){
    if (senha.value != confirmar.value) {
        alert("Senhas não conferem");
    }else{
        return true;
    }
}